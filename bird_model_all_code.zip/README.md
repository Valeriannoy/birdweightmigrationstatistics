# Bird migration energetics: simulation package

Code, figures and results behind the paper "Energy Landscapes, Stopover Networks and Reproductive Constraints".

## Files
- `sim.py`: the model (flight, stopover, route choice, reproduction, population matrix) and the 7 scenarios.
- `figs.py`: runs all scenarios, builds the two sensitivity grids and draws the 5 figures. Takes about 2 to 3 minutes.
- `exp2.py`: extra experiments for Figure 6 (fitness against departure date under lower fat deposition; reproduction against calcium uptake). Results in `exp2.json`; the figure was drawn from them.
- `tests.py`: sanity tests. Run `python3 tests.py`.
- `summ.json`: scenario results (arrival probability, reproductive index, growth rate, route share, bearing, bird-days per site).
- `grids.json`, `add.json`: sensitivity-grid values and the additivity numbers.
- `figs/`: the six figures (PNG).

## Run
    pip install numpy scipy matplotlib
    python3 tests.py
    python3 figs.py

Random seeds are fixed, so results reproduce exactly.

## Important
All parameters in `sim.py` (dictionary `P` and the node list `NODES`) are assumptions for a generic 2 kg goose-type bird, not estimates from data. Potential fecundity is calibrated so baseline growth rate = 1, so only differences between scenarios are meaningful. Scenarios are sensitivity tests, not climate projections.

## Where to change things
- Bird traits and timing: dictionary `P` at the top of `sim.py`.
- Sites (position, habitat quality, calcium uptake): list `NODES`.
- Scenarios: list `SC` at the bottom of `sim.py`.
