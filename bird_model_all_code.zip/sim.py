import numpy as np
from collections import Counter

P = dict(
    m_lean=1.80, f_max=0.45, f_safe=0.06, f_dead=0.02, f_req=0.20,
    Gamma=0.30, g=9.81, eps=37e6, Va=17.0, r_max=0.015,
    beta=50.0, T_ref=7.0,
    d0=70.0, slope=0.027, sigma=15.0,
    t_depart=95, t_melt=152, t_deadline=200,
    vbar=1.5, wsd=4.0, wrho=0.7, ca_cap=1.5, ca_req=1.0,
)
P['kappa'] = P['Gamma'] * P['g'] / P['eps'] * 1000.0
P_W_FOOD = 0.3

NODES = [
    ("W", 0, 0, 0.0, 0.0), ("S1", -150, 700, 0.9, 0.12), ("S2", 250, 750, 0.6, 0.12),
    ("S3", -100, 1400, 0.9, 0.12), ("S4", 400, 1450, 0.6, 0.12), ("S5", 700, 1500, 0.4, 0.12),
    ("S6", 100, 2100, 0.8, 0.12), ("S7", 600, 2200, 0.6, 0.12), ("S8", 350, 2600, 0.8, 0.12),
    ("B", 400, 3050, 0.0, 0.0),
]
NAMES = [n[0] for n in NODES]
XY = np.array([[n[1], n[2]] for n in NODES], float)
Q0 = np.array([n[3] for n in NODES])
CA0 = np.array([n[4] for n in NODES])
DIST = np.linalg.norm(XY[:, None] - XY[None], axis=2)
BEAR = np.degrees(np.arctan2(XY[None, :, 0] - XY[:, None, 0], XY[None, :, 1] - XY[:, None, 1]))
IB = len(NODES) - 1


def make_scenario(**kw):
    s = dict(dv=0.0, shift=0.0, depart_shift=0, melt_shift=0.0, hmult={}, dry=[], ca={}, name='')
    s.update(kw); return s


def habitat(j, t, sc):
    peak = P['d0'] - sc['shift'] + P['slope'] * XY[j, 1]
    pulse = max(0.1, np.exp(-0.5 * ((t - peak) / P['sigma']) ** 2))
    return Q0[j] * sc['hmult'].get(j, 1.0) * pulse


def burn(m_dep, D, phi=1.0):
    return m_dep * (1 - np.exp(-P['kappa'] * phi * D))


def f_need(i, j, phi=1.0):
    return (P['m_lean'] + P['f_safe']) * np.exp(P['kappa'] * phi * DIST[i, j]) - P['m_lean']


def choose(i, t, f, sc, rng):
    cands, U = [], []
    for j in range(len(NODES)):
        if j == i or XY[j, 1] < XY[i, 1] + 150: continue
        if j != IB and j in sc['dry']: continue
        if f_need(i, j) > P['f_max']: continue
        T = DIST[i, j] / (P['Va'] * 86.4)
        gain = 0.0 if j == IB else P['r_max'] * habitat(j, t + T, sc) * P['T_ref']
        m_nom = P['m_lean'] + 0.3
        u = gain - burn(m_nom, DIST[i, j]) - (0.0 if j == IB else burn(m_nom, DIST[j, IB]))
        cands.append(j); U.append(u)
    if not cands: return None
    U = np.array(U); p = np.exp(P['beta'] * (U - U.max())); p /= p.sum()
    return cands[rng.choice(len(cands), p=p)]


def run(sc, N=3000, seed=1, t_depart=None, keep=0):
    rng = np.random.default_rng(seed)
    out = dict(ok=0, fat=[], arr=[], dur=[], rep=[], fail=Counter(), days=np.zeros(len(NODES)),
               first=[], east=0, late=[], ca=[], trajs=[], paths=[])
    t_dep = (P['t_depart'] if t_depart is None else t_depart) - sc['depart_shift']
    melt = P['t_melt'] - sc['melt_shift']
    vm = P['vbar'] + sc['dv']
    for n in range(N):
        i, t, f, ca = 0, t_dep, P['f_max'] * 0.8, 0.0
        au = av = 0.0; stay = 0; cum = 0.0; traj = [(0.0, t, f)]
        dest = choose(i, t, f, sc, rng); path = [0]; ok = False; first_bearing = None
        while t < P['t_deadline']:
            if dest is None:
                out['fail']['no feasible site'] += 1; break
            r = np.sqrt(1 - P['wrho'] ** 2) * P['wsd']
            au = P['wrho'] * au + r * rng.normal(); av = P['wrho'] * av + r * rng.normal()
            b = np.radians(BEAR[i, dest])
            Vg = P['Va'] + au * np.sin(b) + (vm + av) * np.cos(b)
            phi = P['Va'] / max(Vg, 0.2 * P['Va'])
            final = dest == IB
            m_target = P['m_lean'] + (P['f_req'] if final else P['f_safe'])
            need = m_target * np.exp(P['kappa'] * phi * DIST[i, dest]) - P['m_lean']
            ready = (need <= P['f_max']) and (f >= need) and (not final or t >= melt - 3)
            if ready:
                phi_real = phi * np.exp(0.12 * rng.normal())
                m_arr = (P['m_lean'] + f) * np.exp(-P['kappa'] * phi_real * DIST[i, dest])
                if first_bearing is None: first_bearing = BEAR[i, dest]
                if m_arr - P['m_lean'] < P['f_dead']:
                    out['fail']['fuel exhausted'] += 1; break
                traj.append((cum, t, f))
                f = m_arr - P['m_lean']; t += DIST[i, dest] / (max(Vg, 3.0) * 86.4); cum += DIST[i, dest]
                traj.append((cum, t, f)); i = dest; path.append(i)
                if i == IB: ok = True; break
                dest = choose(i, t, f, sc, rng); stay = 0
                continue
            h = P_W_FOOD if i == 0 else habitat(i, t, sc)
            f = min(P['f_max'], f + P['r_max'] * h * (1 - f / P['f_max']))
            out['days'][i] += 1; stay += 1
            if stay % 7 == 0:
                nd = choose(i, t, f, sc, rng); dest = nd if nd is not None else dest
            if XY[i, 1] >= 2000 and t >= melt - 14:
                ca = min(P['ca_cap'], ca + sc['ca'].get(i, CA0[i]))
            t += 1
        else:
            out['fail']['deadline passed'] += 1
        if ok:
            out['ok'] += 1; out['fat'].append(f); out['arr'].append(t); out['dur'].append(t - t_dep)
            e = min(1, f / P['f_req']); c = min(1, ca / P['ca_req'])
            late = max(0.0, t - melt); out['late'].append(late)
            out['rep'].append(min(e, c) * max(0.0, 1 - late / 25.0)); out['ca'].append(c)
            out['east'] += int(any(k in path for k in (2, 4, 5, 7)))
        else:
            out['rep'].append(0.0)
        out['first'].append(first_bearing if first_bearing is not None else np.nan)
        if n < keep: out['trajs'].append((traj, ok)); out['paths'].append(path)
    return out


def leslie_lambda(Parr, rep, F_pot, s0=0.55, s1=0.90, sa=0.93):
    A = np.array([[0, 0, F_pot * rep * s0], [s1 * Parr, 0, 0], [0, s1 * Parr, sa * Parr]])
    return max(np.linalg.eigvals(A).real)


def summarise(o, N):
    ok = o['ok']; pa = ok / N
    fb = np.array(o['first']); fb = fb[~np.isnan(fb)]; th = np.radians(fb)
    return dict(P_arr=pa, se=np.sqrt(pa * (1 - pa) / N),
                fat=np.mean(o['fat']) if ok else np.nan, arr=np.mean(o['arr']) if ok else np.nan,
                rep=np.mean(o['rep']), late=np.mean(o['late']) if o['late'] else np.nan,
                ca=np.mean(o['ca']) if o['ca'] else np.nan, east=o['east'] / max(ok, 1),
                bearing=np.degrees(np.arctan2(np.sin(th).mean(), np.cos(th).mean())),
                days=o['days'] / N, fail=o['fail'].most_common(2))


SC = [
    make_scenario(name='Baseline'),
    make_scenario(name='A. Weaker tailwind', dv=-2.0),
    make_scenario(name='B. Earlier food + thaw, departure fixed', shift=10.0, melt_shift=7.0),
    make_scenario(name='C. As B, departure also earlier', shift=10.0, melt_shift=7.0, depart_shift=10),
    make_scenario(name='D. Western wetlands degrade', hmult={1: 0.5}, dry=[3]),
    make_scenario(name='E. Calcium-poor staging', ca={6: 0.06, 7: 0.06, 8: 0.06}),
    make_scenario(name='F. Combined A+B+D', dv=-2.0, shift=10.0, melt_shift=7.0, hmult={1: 0.5}, dry=[3]),
]
