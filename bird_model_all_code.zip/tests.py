"""Sanity tests for the migration simulation. Run: python3 tests.py"""
import numpy as np
import sim
from scipy.optimize import brentq

P = sim.P


def test_range():
    dmax = np.log((P['m_lean'] + P['f_max']) / (P['m_lean'] + P['f_dead'])) / P['kappa']
    assert 2600 < dmax < 2750, dmax
    print(f"ok  max range {dmax:.0f} km (paper: about 2,670 km)")


def test_fuel_rule():
    # fuel computed by f_need must leave exactly f_safe on arrival (no wind)
    f = sim.f_need(0, 3)
    m_arr = (P['m_lean'] + f) * np.exp(-P['kappa'] * sim.DIST[0, 3])
    assert abs(m_arr - P['m_lean'] - P['f_safe']) < 1e-9
    print("ok  fuel requirement leaves exactly the safety margin")


def test_wind_effect():
    assert sim.f_need(0, 3, phi=1.3) > sim.f_need(0, 3, phi=1.0) > sim.f_need(0, 3, phi=0.8)
    print("ok  headwind raises, tailwind lowers fuel need")


def test_reproducible():
    a = sim.summarise(sim.run(sim.SC[0], N=300, seed=3), 300)
    b = sim.summarise(sim.run(sim.SC[0], N=300, seed=3), 300)
    assert a['P_arr'] == b['P_arr'] and a['rep'] == b['rep']
    print("ok  same seed gives identical results")


def test_scenarios():
    N = 1500
    r = {s['name']: sim.summarise(sim.run(s, N=N, seed=21), N) for s in sim.SC}
    base, F, D, E = r['Baseline'], r['F. Combined A+B+D'], r['D. Western wetlands degrade'], r['E. Calcium-poor staging']
    assert base['P_arr'] > 0.97
    assert F['P_arr'] < base['P_arr'] - 0.1
    assert D['east'] > base['east'] + 0.4 and D['bearing'] > base['bearing'] + 8
    assert abs(E['P_arr'] - base['P_arr']) < 0.01 and E['rep'] < base['rep'] - 0.1
    print("ok  baseline success, combined collapse, route shift, calcium decoupling")


def test_lambda_calibration():
    N = 1500
    b = sim.summarise(sim.run(sim.SC[0], N=N, seed=21), N)
    Fp = brentq(lambda F: sim.leslie_lambda(b['P_arr'], b['rep'], F) - 1, 0.05, 100)
    assert abs(sim.leslie_lambda(b['P_arr'], b['rep'], Fp) - 1) < 1e-6
    assert sim.leslie_lambda(b['P_arr'] - .2, b['rep'], Fp) < 1
    print(f"ok  lambda calibrated to 1 (F_pot = {Fp:.3f}); lower survival lowers lambda")


if __name__ == '__main__':
    for t in (test_range, test_fuel_rule, test_wind_effect, test_reproducible, test_scenarios, test_lambda_calibration):
        t()
    print("all tests passed")
