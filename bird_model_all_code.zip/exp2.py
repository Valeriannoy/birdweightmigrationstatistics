import sim, numpy as np, json
from scipy.optimize import brentq
N=1000
b=sim.summarise(sim.run(sim.SC[0],N=4000,seed=21),4000)
Fp=brentq(lambda F: sim.leslie_lambda(b['P_arr'],b['rep'],F)-1,0.05,100)
base_r=sim.P['r_max']
dates=list(range(50,111,5))
out={'dates':dates,'Fp':Fp}
for label,r,sc in [('baseline',0.015,sim.SC[0]),('deposition -10%',0.0135,sim.SC[0]),('deposition -20%',0.012,sim.SC[0])]:
    sim.P['r_max']=r; W=[]; Pa=[]
    for d in dates:
        o=sim.run(sc,N=N,seed=7,t_depart=d); s=sim.summarise(o,N); W.append(s['rep']); Pa.append(s['P_arr'])
    out[label]={'W':W,'P':Pa}
sim.P['r_max']=base_r
# calcium uptake curve
cs=[0.02,0.04,0.06,0.08,0.10,0.12,0.16]; Rc=[]
for c in cs:
    sc=sim.make_scenario(ca={6:c,7:c,8:c}); o=sim.run(sc,N=N,seed=7); Rc.append(sim.summarise(o,N)['rep'])
out['ca']={'x':cs,'R':Rc}
json.dump(out,open('exp2.json','w'),indent=1)
for k in ('baseline','deposition -10%','deposition -20%'):
    W=np.array(out[k]['W']); i=W.argmax(); print(k,'best departure',dates[i],'Wmax',round(W[i],3),'W@95',round(W[dates.index(95)],3),'lambda@best',round(sim.leslie_lambda(out[k]['P'][i],W[i],Fp),3))
    print('  W:',np.round(W,3))
print('Ca',np.round(Rc,3))
