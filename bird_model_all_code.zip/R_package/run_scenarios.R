# Riproduce la tabella degli scenari e la confronta con i risultati Python.
# Esegui dalla cartella R_package:  source("run_scenarios.R")
source("sim.R")
M <- load_model("data")
N <- 4000                     # per una prova veloce usa N <- 500

# 0) controlli rapidi sulle formule (corrispondono a tests.py)
cat("D_max  =", round(d_max(M$P)), "km (atteso ~2666)\n")
stopifnot(abs(arrival_mass(M$P$m_lean + fuel_needed(1500, 1, M$P), 1500, 1, M$P$kappa)
              - (M$P$m_lean + M$P$f_safe)) < 1e-9)
stopifnot(fuel_needed(1500, 1.3, M$P) > fuel_needed(1500, 1, M$P),
          fuel_needed(1500, 1, M$P) > fuel_needed(1500, 0.8, M$P))

# 1) tutti gli scenari
out <- lapply(SC, function(sc) run_sim(M, sc, N = N, seed = 21))
tab <- do.call(rbind, lapply(out, summarise_run))
tab <- cbind(scenario = sapply(SC, `[[`, "name"), tab)

# 2) calibrazione di F_pot sul baseline e lambda per scenario
Fp <- calibrate_Fpot(tab$arrival_prob[1], tab$repro_index[1])
tab$lambda <- mapply(leslie_lambda, tab$arrival_prob, tab$repro_index, MoreArgs = list(F_pot = Fp))
cat("F_pot =", round(Fp, 3), "(atteso ~0.195)\n")
print(format(tab, digits = 3), row.names = FALSE)

# 3) confronto con Python
py <- read.csv("data/expected_results.csv")
cmp <- data.frame(scenario = tab$scenario,
                  P_R = tab$arrival_prob, P_py = py$arrival_prob,
                  rep_R = tab$repro_index, rep_py = py$repro_index,
                  lam_R = tab$lambda, lam_py = py$growth_rate_lambda)
cat("\nConfronto R vs Python (devono concordare entro ~2-3 errori standard):\n")
print(format(cmp, digits = 3), row.names = FALSE)
write.csv(tab, "results_R.csv", row.names = FALSE)
