# Versione R del modello (per provarlo in prima persona)

**Nota onesta:** R non e' installato nel mio ambiente, quindi `sim.R` e' una traduzione fedele di `sim.py` ma **non l'ho eseguita**. Se compare un errore, mandamelo e lo correggo.

## Contenuto
- `sim.R` : formule come funzioni R (Breguet `fuel_needed`, `d_max`, `habitat_pulse`, `softmax_p`, `repro_index`, `leslie_lambda`, ...) + simulazione individuale `run_sim()`.
- `run_scenarios.R` : controlli rapidi, 7 scenari, calibrazione di F_pot, confronto con Python.
- `data/` (tutti CSV, leggibili con `read.csv`):
  - `parameters.csv` parametri; `nodes.csv` siti (x, y, qualita', calcio); `scenarios.csv` descrizione scenari
  - `expected_results.csv`, `expected_bird_days.csv` risultati di riferimento da Python (4000 uccelli, seed 21)
  - `grid_wind_habitat.csv`, `grid_phenology_departure.csv` griglie di sensibilita' (Fig. 5)
  - `fitness_vs_departure.csv`, `calcium_vs_reproduction.csv` (Fig. 6)

## Come eseguire
    setwd("R_package")
    source("run_scenarios.R")

Basta R base (nessun pacchetto). Con N = 4000 il ciclo e' lento in R (alcuni minuti): per provare usa N = 500.

## Cosa aspettarsi
Il generatore casuale di R e' diverso da quello di numpy, quindi **i numeri non saranno identici**, ma devono coincidere statisticamente:
baseline P ≈ 0.99, indice riproduttivo ≈ 0.91, lambda = 1 con F_pot ≈ 0.195; scenario F: P ≈ 0.79, lambda ≈ 0.78; D sposta la quota di corridoio orientale da ~0.35 a ~0.91.

## Indici dei nodi in R (parte da 1)
W=1, S1=2, S2=3, S3=4, S4=5, S5=6, S6=7, S7=8, S8=9, B=10. In `make_scenario`, `hmult` e `ca` sono vettori nominati con questi indici, `dry` e' un vettore di indici.

## Provare altri scenari
    sc <- make_scenario("mio", dv = -1, shift = 5, melt_shift = 3.5, depart_shift = 5)
    o  <- run_sim(M, sc, N = 1000); summarise_run(o)
Per cambiare un parametro: modifica `data/parameters.csv` (o `M$P$r_max <- 0.0135` dopo `load_model`; ricordati che `kappa` si ricalcola solo in `load_model`).

Vale ancora: i parametri sono assunzioni per un'oca generica, non stime da dati; gli scenari sono test di sensibilita', non proiezioni climatiche.
