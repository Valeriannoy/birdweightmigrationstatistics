# =====================================================================
#  Bird migration energetics - R port of sim.py
#  ATTENZIONE: tradotto da Python, NON eseguito nel sandbox (R non disponibile).
#  Se qualcosa non gira, scrivimi il messaggio d'errore.
#  Uso:  source("sim.R"); vedi run_scenarios.R
# =====================================================================

# ---- 1. Dati ---------------------------------------------------------
load_model <- function(dir = "data") {
  p  <- read.csv(file.path(dir, "parameters.csv"), stringsAsFactors = FALSE)
  P  <- as.list(setNames(p$value, p$name))
  P$kappa <- P$Gamma * P$g / P$eps * 1000          # costo per km, eq. (1)
  nodes <- read.csv(file.path(dir, "nodes.csv"), stringsAsFactors = FALSE)
  nodes$quality[1] <- 0                             # W: usa P$w_food
  n <- nrow(nodes)
  DIST <- as.matrix(dist(nodes[, c("x_km", "y_km")]))
  dx <- outer(nodes$x_km, nodes$x_km, function(a, b) b - a)   # [i,j] = x_j - x_i
  dy <- outer(nodes$y_km, nodes$y_km, function(a, b) b - a)
  BEAR <- atan2(dx, dy) * 180 / pi                  # gradi, 0 = nord
  list(P = P, nodes = nodes, DIST = DIST, BEAR = BEAR, n = n, IB = n)
}

# ---- 2. Formule del paper -------------------------------------------
# (1) Breguet: massa all'arrivo
arrival_mass <- function(m_dep, D, phi = 1, kappa) m_dep * exp(-kappa * phi * D)
# (2) grasso necessario per coprire D km lasciando f_safe
fuel_needed <- function(D, phi = 1, P, f_end = P$f_safe)
  (P$m_lean + f_end) * exp(P$kappa * phi * D) - P$m_lean
# (3) distanza massima (km)
d_max <- function(P) log((P$m_lean + P$f_max) / (P$m_lean + P$f_dead)) / P$kappa
# (4) fattore vento
wind_factor <- function(Va, Vg) Va / pmax(Vg, 0.2 * Va)
# (5) pulso di habitat (green wave)
habitat_pulse <- function(q, t, y_km, P, shift = 0, hmult = 1) {
  peak <- P$d0 - shift + P$slope * y_km
  q * hmult * pmax(0.1, exp(-0.5 * ((t - peak) / P$sigma)^2))
}
# (6) ingrasso in un giorno di sosta
fat_step <- function(f, h, P) min(P$f_max, f + P$r_max * h * (1 - f / P$f_max))
# (7) scelta rotta: probabilita' softmax
softmax_p <- function(U, beta) { e <- exp(beta * (U - max(U))); e / sum(e) }
# (8) riproduzione: regola del minimo (Liebig) con penalita' di ritardo
repro_index <- function(f_arr, ca, late, P, L = 25)
  min(1, f_arr / P$f_req, ca / P$ca_req) * max(0, 1 - late / L)
# (9) matrice di Leslie a 3 stadi e lambda
leslie_lambda <- function(Parr, rep, F_pot, s0 = 0.55, s1 = 0.90, sa = 0.93) {
  A <- matrix(c(0,         0,         F_pot * rep * s0,
                s1 * Parr, 0,         0,
                0,         s1 * Parr, sa * Parr), nrow = 3, byrow = TRUE)
  max(Re(eigen(A)$values))
}
# calibrazione: F_pot tale che lambda = 1 nello scenario base
calibrate_Fpot <- function(Parr, rep)
  uniroot(function(F) leslie_lambda(Parr, rep, F) - 1, c(0.05, 100))$root
# direzione media circolare (gradi) e concentrazione
circ_mean <- function(deg) { th <- deg * pi / 180
  c(mean_deg = atan2(mean(sin(th)), mean(cos(th))) * 180 / pi,
    Lambda = sqrt(mean(sin(th))^2 + mean(cos(th))^2)) }

# ---- 3. Scenari ------------------------------------------------------
make_scenario <- function(name = "", dv = 0, shift = 0, depart_shift = 0,
                          melt_shift = 0, hmult = numeric(0), dry = integer(0),
                          ca = numeric(0)) {
  # hmult e ca: vettori NOMINATI con l'indice del nodo (1 = W, 2 = S1, ... 10 = B)
  list(name = name, dv = dv, shift = shift, depart_shift = depart_shift,
       melt_shift = melt_shift, hmult = hmult, dry = dry, ca = ca)
}
# Indici (R parte da 1):  W=1, S1=2, S2=3, S3=4, S4=5, S5=6, S6=7, S7=8, S8=9, B=10
SC <- list(
  make_scenario("Baseline"),
  make_scenario("A. Weaker tailwind", dv = -2),
  make_scenario("B. Earlier food + thaw", shift = 10, melt_shift = 7),
  make_scenario("C. As B, departure earlier", shift = 10, melt_shift = 7, depart_shift = 10),
  make_scenario("D. Western wetlands degrade", hmult = c("2" = 0.5), dry = 4),
  make_scenario("E. Calcium-poor staging", ca = c("7" = 0.06, "8" = 0.06, "9" = 0.06)),
  make_scenario("F. Combined A+B+D", dv = -2, shift = 10, melt_shift = 7,
                hmult = c("2" = 0.5), dry = 4)
)

# ---- 4. Simulazione individuale -------------------------------------
run_sim <- function(M, sc, N = 4000, seed = 21, t_depart = NULL) {
  set.seed(seed)
  P <- M$P; nd <- M$nodes; DIST <- M$DIST; BEAR <- M$BEAR; IB <- M$IB; n <- M$n
  y <- nd$y_km
  getm <- function(v, j) { x <- v[as.character(j)]; if (is.na(x)) 1 else x }
  hab <- function(j, t) habitat_pulse(nd$quality[j], t, y[j], P, sc$shift, getm(sc$hmult, j))
  choose <- function(i, t) {
    cand <- integer(0); U <- numeric(0)
    for (j in seq_len(n)) {
      if (j == i || y[j] < y[i] + P$min_step_km) next
      if (j != IB && j %in% sc$dry) next
      if (fuel_needed(DIST[i, j], 1, P) > P$f_max) next
      T <- DIST[i, j] / (P$Va * 86.4)
      gain <- if (j == IB) 0 else P$r_max * hab(j, t + T) * P$T_ref
      m_nom <- P$m_lean + 0.3
      u <- gain - m_nom * (1 - exp(-P$kappa * DIST[i, j])) -
        (if (j == IB) 0 else m_nom * (1 - exp(-P$kappa * DIST[j, IB])))
      cand <- c(cand, j); U <- c(U, u)
    }
    if (length(cand) == 0) return(NA_integer_)
    cand[sample.int(length(cand), 1, prob = softmax_p(U, P$beta))]
  }
  t_dep <- (if (is.null(t_depart)) P$t_depart else t_depart) - sc$depart_shift
  melt  <- P$t_melt - sc$melt_shift
  vm    <- P$vbar + sc$dv
  east_nodes <- c(3, 5, 6, 8)                       # S2, S4, S5, S7
  days <- numeric(n)
  res <- data.frame(ok = logical(N), f_arr = NA_real_, t_arr = NA_real_,
                    rep = 0, late = NA_real_, ca = NA_real_, east = NA, first = NA_real_,
                    fail = "")
  for (b in seq_len(N)) {
    i <- 1; t <- t_dep; f <- P$f_max * P$f0_frac; ca <- 0
    au <- 0; av <- 0; stay <- 0
    dest <- choose(i, t); path <- 1; ok <- FALSE; fb <- NA_real_; failed <- ""
    broke <- FALSE
    while (t < P$t_deadline) {
      if (is.na(dest)) { failed <- "no feasible site"; broke <- TRUE; break }
      r  <- sqrt(1 - P$wrho^2) * P$wsd
      au <- P$wrho * au + r * rnorm(1); av <- P$wrho * av + r * rnorm(1)
      bb <- BEAR[i, dest] * pi / 180
      Vg  <- P$Va + au * sin(bb) + (vm + av) * cos(bb)
      phi <- wind_factor(P$Va, Vg)
      final <- dest == IB
      m_target <- P$m_lean + (if (final) P$f_req else P$f_safe)
      need  <- m_target * exp(P$kappa * phi * DIST[i, dest]) - P$m_lean
      ready <- (need <= P$f_max) && (f >= need) && (!final || t >= melt - 3)
      if (ready) {
        phi_real <- phi * exp(P$forecast_sd * rnorm(1))
        m_arr <- (P$m_lean + f) * exp(-P$kappa * phi_real * DIST[i, dest])
        if (is.na(fb)) fb <- BEAR[i, dest]
        if (m_arr - P$m_lean < P$f_dead) { failed <- "fuel exhausted"; broke <- TRUE; break }
        f <- m_arr - P$m_lean
        t <- t + DIST[i, dest] / (max(Vg, 3) * 86.4)
        i <- dest; path <- c(path, i)
        if (i == IB) { ok <- TRUE; broke <- TRUE; break }
        dest <- choose(i, t); stay <- 0
        next
      }
      h <- if (i == 1) P$w_food else hab(i, t)
      f <- fat_step(f, h, P)
      days[i] <- days[i] + 1; stay <- stay + 1
      if (stay %% 7 == 0) { nn <- choose(i, t); if (!is.na(nn)) dest <- nn }
      if (y[i] >= 2000 && t >= melt - P$ca_window) {
        up <- sc$ca[as.character(i)]; if (is.na(up)) up <- nd$ca_uptake_per_day[i]
        ca <- min(P$ca_cap, ca + up)
      }
      t <- t + 1
    }
    if (!broke) failed <- "deadline passed"
    res$first[b] <- fb
    if (ok) {
      late <- max(0, t - melt)
      cc <- min(1, ca / P$ca_req)
      res$ok[b] <- TRUE; res$f_arr[b] <- f; res$t_arr[b] <- t; res$late[b] <- late
      res$ca[b] <- cc; res$rep[b] <- repro_index(f, ca, late, P)
      res$east[b] <- any(path %in% east_nodes)
    } else res$fail[b] <- failed
  }
  list(birds = res, days = days / N, N = N)
}

summarise_run <- function(o) {
  b <- o$birds; N <- o$N; ok <- sum(b$ok); pa <- ok / N
  fb <- b$first[!is.na(b$first)]
  data.frame(arrival_prob = pa, arrival_se = sqrt(pa * (1 - pa) / N),
             repro_index = mean(b$rep), mean_days_late = mean(b$late, na.rm = TRUE),
             eastern_share = mean(b$east[b$ok]), bearing_deg = circ_mean(fb)[["mean_deg"]],
             Lambda = circ_mean(fb)[["Lambda"]])
}
