import sim, numpy as np, json
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.optimize import brentq
BL,OR,AQ,INK,MUT,GR='#2a78d6','#eb6834','#1baf7a','#0b0b0b','#52514e','#d9d8d2'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':MUT,'axes.labelcolor':MUT,'xtick.color':MUT,'ytick.color':MUT,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fcfcfb','axes.facecolor':'#fcfcfb','savefig.facecolor':'#fcfcfb'})
N=4000
runs={s['name']:sim.run(s,N=N,seed=21,keep=300) for s in sim.SC}
summ={k:sim.summarise(v,N) for k,v in runs.items()}
b=summ['Baseline']; Fp=brentq(lambda F: sim.leslie_lambda(b['P_arr'],b['rep'],F)-1,0.05,100)
lam={k:sim.leslie_lambda(v['P_arr'],v['rep'],Fp) for k,v in summ.items()}
json.dump({k:dict(P=v['P_arr'],R=v['rep'],lam=lam[k],east=v['east'],bear=v['bearing'],late=v['late'],days=list(map(float,v['days']))) for k,v in summ.items()},open('summ.json','w'),indent=1)

# Fig 1: fat trajectories baseline
fig,ax=plt.subplots(figsize=(7.2,3.6))
for traj,ok in runs['Baseline']['trajs'][:60]:
    x=[p[0] for p in traj]; y=[p[2] for p in traj]
    ax.plot(x,y,color=BL if ok else OR,lw=.7,alpha=.45)
ax.axhline(sim.P['f_dead'],color=OR,ls='--',lw=1.2); ax.text(30,sim.P['f_dead']+.01,'F_min (0.02 kg)',color=OR,fontsize=8)
ax.axhline(sim.P['f_req'],color=MUT,ls=':',lw=1.2); ax.text(30,sim.P['f_req']+.01,'fat needed to breed (0.20 kg)',color=MUT,fontsize=8)
for j in range(1,9): ax.axvline(sim.XY[j,1],color=GR,lw=.5,zorder=0)
ax.set_xlabel('Distance travelled along route (km)'); ax.set_ylabel('Fat reserve (kg)'); ax.set_xlim(0,3100); ax.set_ylim(0,.5)
ax.set_title('Fat reserve of 60 simulated females, baseline: sawtooth of flights and refuelling',loc='left',fontsize=10,color=INK)
plt.tight_layout(); plt.savefig('figs/fig1_fat.png',dpi=170); plt.close()

# Fig 2: occupancy maps
fig,axs=plt.subplots(1,3,figsize=(9.6,4.4),sharey=True)
for ax,(nm,ttl) in zip(axs,[('Baseline','Baseline'),('D. Western wetlands degrade','D. Western wetlands degrade'),('F. Combined A+B+D','F. Combined A+B+D')]):
    o=runs[nm]; E={}
    for p in o['paths']:
        for a,c in zip(p[:-1],p[1:]): E[(a,c)]=E.get((a,c),0)+1
    n=len(o['paths'])
    for (a,c),v in E.items(): ax.plot(sim.XY[[a,c],0],sim.XY[[a,c],1],color=BL,lw=.4+5*v/n,alpha=.55,solid_capstyle='round')
    d=summ[nm]['days']
    for j in range(len(sim.NODES)):
        ax.scatter(*sim.XY[j],s=25+d[j]*9,color=OR if 0<j<9 else INK,edgecolor='#fcfcfb',lw=1.5,zorder=3)
        ax.text(sim.XY[j,0]+60,sim.XY[j,1]-60,sim.NAMES[j],fontsize=7.5,color=MUT)
    ax.set_title(f"{ttl}\nP={summ[nm]['P_arr']:.2f}, bearing {summ[nm]['bearing']:+.0f}°",loc='left',fontsize=9,color=INK)
    ax.set_xlim(-400,950); ax.set_xlabel('East (km)')
axs[0].set_ylabel('North (km)')
plt.tight_layout(); plt.savefig('figs/fig2_routes.png',dpi=170); plt.close()

# Fig 3: scenario outcomes
names=[s['name'] for s in sim.SC]; short=['Base','A wind','B mismatch','C B + earlier\ndeparture','D habitat','E calcium','F A+B+D']
fig,axs=plt.subplots(1,3,figsize=(9.6,3.2))
for ax,(key,lab,vals) in zip(axs,[('P','Arrival probability',[summ[n]['P_arr'] for n in names]),('R','Reproductive index',[summ[n]['rep'] for n in names]),('lam','Population growth rate λ',[lam[n] for n in names])]):
    cols=[GR]+[BL]*5+[OR]; ax.barh(range(7)[::-1],vals,color=cols,height=.62)
    ax.set_yticks(range(7)[::-1]); ax.set_yticklabels(short if key=='P' else ['']*7,fontsize=8)
    lo=min(vals); ax.set_xlim(0,1.12)
    for y,v in zip(range(7)[::-1],vals): ax.text(v+.004,y,f'{v:.2f}',va='center',fontsize=8,color=INK)
    ax.set_title(lab,loc='left',fontsize=9,color=INK)
plt.tight_layout(); plt.savefig('figs/fig3_scenarios.png',dpi=170); plt.close()

# Fig 4: additivity
fig,ax=plt.subplots(figsize=(5.2,3.2))
dP=[1-summ[n]['P_arr']/b['P_arr'] for n in names[1:]]
dl=[1-lam[n]/1 for n in names]
sing=[names[1],names[2],names[4]]
sum_l=sum(1-lam[n] for n in sing); obs_l=1-lam[names[6]]
sum_P=sum(b['P_arr']-summ[n]['P_arr'] for n in sing); obs_P=b['P_arr']-summ[names[6]]['P_arr']
x=np.arange(2); w=.36
ax.bar(x-w/2,[sum_P*100,sum_l*100],w,color=GR,label='Sum of single effects (A, B, D)')
ax.bar(x+w/2,[obs_P*100,obs_l*100],w,color=OR,label='Combined scenario F')
for xi,v in zip(x-w/2,[sum_P*100,sum_l*100]): ax.text(xi,v+.5,f'{v:.1f}',ha='center',fontsize=8)
for xi,v in zip(x+w/2,[obs_P*100,obs_l*100]): ax.text(xi,v+.5,f'{v:.1f}',ha='center',fontsize=8)
ax.set_xticks(x); ax.set_xticklabels(['Loss in arrival\nprobability (pp)','Loss in growth\nrate λ (%)']); ax.set_ylim(0,32); ax.legend(frameon=False,fontsize=8,loc='upper left')
ax.set_title('Combined effect far exceeds the sum of parts',loc='left',fontsize=10,color=INK)
plt.tight_layout(); plt.savefig('figs/fig4_additivity.png',dpi=170); plt.close()
json.dump(dict(sum_P=sum_P,obs_P=obs_P,sum_l=sum_l,obs_l=obs_l,Fp=Fp),open('add.json','w'))

# Fig 5: heatmaps
def grid(f,xs,ys,Nn=1500):
    R=np.zeros((len(ys),len(xs))); Pm=R.copy()
    for i,y in enumerate(ys):
        for j,x in enumerate(xs):
            o=sim.run(f(x,y),N=Nn,seed=5); s=sim.summarise(o,Nn); R[i,j]=s['rep']; Pm[i,j]=s['P_arr']
    return R,Pm
hab=[1,.75,.5,.25,0]; dv=[0,-1,-2,-3,-4]
Rg,Pg=grid(lambda d,h: sim.make_scenario(dv=d,hmult={1:h,3:h,2:1,4:1}) if h>0 else sim.make_scenario(dv=d,hmult={1:0.001},dry=[3]),dv,hab)
LG=np.vectorize(lambda p,r: sim.leslie_lambda(p,r,Fp))(Pg,Rg)
sh=[0,5,10,15,20]; adv=[0,5,10,15,20]
Rm,Pm=grid(lambda s,a: sim.make_scenario(shift=s,melt_shift=.7*s,depart_shift=a),sh,adv)
LM=np.vectorize(lambda p,r: sim.leslie_lambda(p,r,Fp))(Pm,Rm)
json.dump(dict(LG=LG.tolist(),LM=LM.tolist(),Rm=Rm.tolist(),Pg=Pg.tolist()),open('grids.json','w'))
fig,axs=plt.subplots(1,2,figsize=(9.6,3.8))
for ax,Z,xl,yl,xt,yt,ttl in [(axs[0],LG,'Weaker tail-wind (m/s)','Western-corridor habitat remaining',[str(d) for d in dv],['100%','75%','50%','25%','0%'],'Loss in growth rate (%): wind × habitat loss'),
                              (axs[1],LM,'Earlier food peak and thaw (days)','Departure advanced (days)',[str(s) for s in sh],[str(a) for a in adv],'Loss in growth rate (%): phenology × departure')]:
    L=np.clip((1-Z)*100,0,None)
    im=ax.imshow(L,origin='upper' if ax is axs[0] else 'lower',cmap='Oranges',vmin=0,vmax=28,aspect='auto')
    ax.set_xticks(range(5)); ax.set_xticklabels(xt); ax.set_yticks(range(5)); ax.set_yticklabels(yt)
    for i in range(5):
        for j in range(5): ax.text(j,i,f'{L[i,j]:.0f}',ha='center',va='center',fontsize=8.5,color='white' if L[i,j]>16 else INK)
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(ttl,loc='left',fontsize=9,color=INK)
    for s_ in ax.spines.values(): s_.set_visible(False)
plt.tight_layout(); plt.savefig('figs/fig5_grids.png',dpi=170); plt.close()
print(json.dumps(json.load(open('add.json'))))
print(np.round(LG,3)); print(np.round(LM,3))
